# -*- coding: utf-8 -*-
"""
MusicTagger 核心逻辑
识别文件名 -> 多源搜索(准确率打分) -> 下载封面 -> 写回标签
无 GUI 依赖，可独立测试 / 命令行使用。
"""
import io
import os
import re
import time
import difflib
import urllib.parse

import requests
from mutagen import File as MFile
from mutagen.id3 import ID3, TIT2, TPE1, TALB, TPE2, TRCK, APIC, USLT
from mutagen.flac import FLAC, Picture
from mutagen.mp4 import MP4, MP4Cover
from mutagen.oggvorbis import OggVorbis
from mutagen.wave import WAVE

try:
    from PIL import Image
    HAS_PIL = True
except Exception:
    HAS_PIL = False

UA = {"User-Agent": "MusicTagger/1.0 (personal use)"}
MB_HEADERS = {"User-Agent": "MusicTagger/1.0 (personal-use; contact: user@example.com)"}
QQ_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
              "Referer": "https://y.qq.com/"}
KG_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

# 中文优先：这些源返回中文歌手名，识别打分时给予中文源更高权重
CN_SOURCES = {"QQ音乐", "酷狗", "网易云"}

AUDIO_EXTS = {".mp3", ".flac", ".m4a", ".mp4", ".ogg", ".opus", ".wma", ".aac", ".wav", ".ape", ".wv"}

# ---------------------------------------------------------------- 文件名解析
def parse_filename(path: str) -> dict:
    """从文件名里尽量拆出 艺术家 / 标题 / 版本 / 音轨号。"""
    base = os.path.splitext(os.path.basename(path))[0].strip()
    base = base.replace("_", " ").replace(".", " ").strip()
    # 去掉方括号 / 书名号装饰，如 [Official Audio]、【高清修复】
    base = re.sub(r"\[[^\]]*\]", " ", base)
    base = re.sub(r"【[^】]*】", " ", base)
    base = re.sub(r"\s+", " ", base).strip()

    track = None
    m = re.match(r"^(\d{1,3})[\s._\-]+", base)
    if m:
        track = int(m.group(1))
        base = base[m.end():].strip()

    # Artist - Title (支持各种连接符)
    artist = title = None
    m = re.match(r"^(.+?)\s+(?:-|–|—|~|:)\s+(.+)$", base)
    if m:
        artist = m.group(1).strip().strip("-–—~:")
        title = m.group(2).strip().strip("-–—~:")
    else:
        # 只有标题
        title = base

    # 分离版本标签 (xxx) 保留在标题里，对 DJ 混音很重要
    return {
        "track": track,
        "artist": artist or None,
        "title": title or None,
        "raw": base,
    }


def clean_artist(s: str) -> str:
    if not s:
        return ""
    s = re.sub(r"\s*[\(\[]?(feat\.?|ft\.?|featuring)\s+.*$", "", s, flags=re.I)
    s = re.sub(r"\s*[\(\[](remix|extended|club mix|edit|radio edit|original mix|instrumental|acoustic)[^)\]]*$", "", s, flags=re.I)
    return s.strip()


def clean_title(s: str) -> str:
    if not s:
        return ""
    s = re.sub(r"^(official|lyrics|audio)\s*(\s-)?", "", s, flags=re.I)
    s = s.strip()
    # 去掉版本/场景后缀（Live、DJ版、Remix、演唱会、伴奏等），便于歌词/搜索匹配
    s = re.sub(r"\s*[（\(\[][^）\)\]]*[）\)\]]\s*$", "", s)
    s = re.sub(r"\s*[-~—]\s*(live|dj\s*版?|remix|concert|演唱会|伴奏|instrumental|acoustic|edit|extended|radio|cover|翻唱|现场|原版|完整版|纯音乐|ktv|消音|和声)\s*[版本]?\s*$", "", s, flags=re.I)
    return s.strip()


def strip_version_suffix(s: str) -> str:
    """专门去掉标题末尾的版本标签，返回更干净的标题（用于歌词搜索）。"""
    if not s:
        return ""
    t = s.strip()
    # 括号及其中内容（中文/英文括号）
    t = re.sub(r"\s*[（\(\[【][^）\)\]】]*[）\)\]】]\s*$", "", t)
    # 无括号的 - 后缀版本
    t = re.sub(r"\s*[-~—]\s*(live|dj|remix|concert|演唱会|伴奏|instrumental|acoustic|edit|extended|radio|cover|翻唱|现场|版|完整版|纯音乐)\s*$", "", t, flags=re.I)
    return t.strip()


def norm(s) -> str:
    """归一化，用于相似度比较。"""
    if not s:
        return ""
    s = s.lower()
    s = re.sub(r"[^a-z0-9\u4e00-\u9fff]", "", s)
    return s


def sim(a, b) -> float:
    return difflib.SequenceMatcher(None, norm(a), norm(b)).ratio()


# ---------------------------------------------------------------- 多源搜索
def search_itunes(artist=None, title=None, limit=8):
    term = " ".join(x for x in (clean_artist(artist), title) if x).strip()
    if not term:
        return []
    try:
        r = requests.get("https://itunes.apple.com/search",
                         params={"term": term, "media": "music", "entity": "song", "limit": limit},
                         timeout=15, headers=UA)
        r.raise_for_status()
        return r.json().get("results", [])
    except Exception:
        return []


def search_deezer(artist=None, title=None, limit=8):
    q = " ".join(x for x in (clean_artist(artist), title) if x).strip()
    if not q:
        return []
    try:
        r = requests.get("https://api.deezer.com/search",
                         params={"q": q, "limit": limit}, timeout=15, headers=UA)
        r.raise_for_status()
        return r.json().get("data", [])
    except Exception:
        return []


def search_musicbrainz(artist=None, title=None, limit=8):
    query = " AND ".join(f"recording:{p}" for p in (title,))
    if artist:
        query += f" AND artist:{artist}"
    try:
        r = requests.get("https://musicbrainz.org/ws/2/recording/",
                         params={"query": query, "fmt": "json", "limit": limit},
                         timeout=20, headers=MB_HEADERS)
        r.raise_for_status()
        return r.json().get("recordings", [])
    except Exception:
        return []


def search_qqmusic(artist=None, title=None, limit=8):
    """QQ音乐搜索：返回中文歌手名/中文标题/中文专辑/封面。"""
    w = " ".join(x for x in (clean_artist(artist), title) if x).strip()
    if not w:
        return []
    out = []
    try:
        r = requests.get("https://c.y.qq.com/soso/fcgi-bin/client_search_cp",
                         params={"w": w, "format": "json", "p": 1, "n": limit},
                         timeout=15, headers=QQ_HEADERS)
        r.raise_for_status()
        songs = r.json().get("data", {}).get("song", {}).get("list", [])
        for s in songs:
            singers = [x.get("name", "") for x in (s.get("singer") or [])]
            songmid = s.get("songmid")
            albummid = (s.get("album") or {}).get("albummid")
            out.append({
                "title": s.get("songname"),
                "artist": "、".join(singers),
                "album": s.get("albumname") or None,
                "mid": songmid,
                "album_mid": albummid,
                "cover_url": f"https://y.gtimg.cn/music/photo_new/T002R300x300M000{albummid}.jpg" if albummid else None,
            })
    except Exception:
        pass
    return out


def _cover_art_archive(mbid):
    if not mbid:
        return None
    for size in ("1200", "500", "250"):
        try:
            r = requests.get(f"https://coverartarchive.org/release/{mbid}/front-{size}",
                             timeout=15, headers=UA)
            if r.status_code == 200:
                return r.content
        except Exception:
            continue
    return None


def _itunes_artwork_url(url) -> str:
    """iTunes 100x100 换成 600x600。"""
    if not url:
        return url
    return re.sub(r"100x100(bb)?\.jpg$", "600x600bb.jpg", url)


# ---------------------------------------------------------------- 识别主流程
def build_candidates(artist, title, album=None):
    """汇总各源候选，统一格式 + 打分。"""
    cands = []

    for it in search_itunes(artist, title):
        cands.append({
            "source": "iTunes",
            "title": it.get("trackName"),
            "artist": it.get("artistName"),
            "album": it.get("collectionName"),
            "album_artist": it.get("artistName"),
            "cover_url": _itunes_artwork_url(it.get("artworkUrl100")),
            "mbid": None,
            "score": 0,
        })

    for dz in search_deezer(artist, title):
        pic = dz.get("album", {}).get("cover_xl") or dz.get("album", {}).get("cover_big")
        cands.append({
            "source": "Deezer",
            "title": dz.get("title"),
            "artist": dz.get("artist", {}).get("name"),
            "album": dz.get("album", {}).get("title"),
            "album_artist": None,
            "cover_url": pic,
            "mbid": None,
            "score": 0,
        })

    for mb in search_musicbrainz(artist, title):
        rel = (mb.get("releases") or [None])[0]
        cands.append({
            "source": "MusicBrainz",
            "title": mb.get("title"),
            "artist": (mb.get("artist-credit") or [{}])[0].get("name"),
            "album": rel.get("title") if rel else None,
            "album_artist": None,
            "cover_url": None,
            "mbid": rel.get("id") if rel else None,
            "score": 0,
        })

    for qq in search_qqmusic(artist, title):
        cands.append({
            "source": "QQ音乐",
            "title": qq["title"],
            "artist": qq["artist"],
            "album": qq["album"],
            "album_artist": None,
            "cover_url": qq["cover_url"],
            "mbid": None,
            "score": 0,
        })

    # 打分：标题相似度最重要，其次艺术家、专辑
    for c in cands:
        s = sim(title, c["title"]) * 5
        if artist:
            s += sim(clean_artist(artist), clean_artist(c["artist"] or "")) * 3
        if album:
            s += sim(album, c["album"] or "") * 2
        # 中文源加权：中国歌手的歌，中文源(QQ音乐/酷狗)返回中文名，优先选
        if c["source"] in CN_SOURCES:
            s += 1.5
        c["score"] = round(s, 3)

    cands.sort(key=lambda x: x["score"], reverse=True)
    return cands


def read_existing_tags(path: str) -> dict:
    """读取文件现有完整标签（供扫描后展示原始信息）。"""
    info = {
        "title": None, "artist": None, "album": None, "album_artist": None,
        "track": None, "lyrics": None, "has_cover": False, "has_lyrics": False,
        "duration": None, "format": os.path.splitext(path)[1].lstrip(".").lower(),
        "size": os.path.getsize(path) if os.path.exists(path) else 0,
    }
    ext = info["format"]

    audio = None
    try:
        if ext == "mp3":
            audio = ID3(path)
        elif ext == "flac":
            audio = FLAC(path)
        elif ext in ("m4a", "mp4"):
            audio = MP4(path)
        elif ext in ("ogg", "opus"):
            audio = OggVorbis(path)
        elif ext == "wav":
            audio = getattr(WAVE(path), "tags", None)
        else:
            mf = MFile(path, easy=False)
            audio = getattr(mf, "tags", None) if mf is not None else None
    except Exception:
        audio = None

    if audio is None:
        return info

    def _v(group, key):
        """从 dict-like 标签取值，兼容 str/list。"""
        try:
            v = group.get(key)
        except Exception:
            return None
        if isinstance(v, (list, tuple)):
            return str(v[0]) if v else None
        return str(v) if v else None

    try:
        # 时长
        fbody = MFile(path, easy=False)
        if fbody is not None and fbody.info is not None:
            info["duration"] = round(float(fbody.info.length), 1)
    except Exception:
        pass

    try:
        if ext in ("flac", "ogg", "opus"):
            info["title"] = _v(audio, "title")
            info["artist"] = _v(audio, "artist")
            info["album"] = _v(audio, "album")
            info["album_artist"] = _v(audio, "albumartist") or _v(audio, "album artist")
            tn = _v(audio, "tracknumber")
            info["track"] = tn.split("/")[0] if tn else None
            info["lyrics"] = _v(audio, "lyrics") or _v(audio, "unsyncedlyrics")
            if ext == "flac":
                info["has_cover"] = bool(getattr(audio, "pictures", None))
            else:
                info["has_cover"] = "metadata_block_picture" in audio
        elif ext in ("m4a", "mp4"):
            info["title"] = _v(audio, "\xa9nam")
            info["artist"] = _v(audio, "\xa9ART")
            info["album"] = _v(audio, "\xa9alb")
            info["album_artist"] = _v(audio, "aART")
            tr = audio.get("trkn")
            if tr:
                info["track"] = str(tr[0][0])
            info["lyrics"] = _v(audio, "\xa9lyr")
            info["has_cover"] = bool(audio.get("covr"))
        elif ext in ("mp3", "wav") or (audio is not None and hasattr(audio, "getall")):
            # ID3 帧（mp3 / wav 的 ID3v2）
            for k in list(audio.keys()):
                try:
                    fr = audio[k]
                    if k.startswith("TIT2") and not info["title"]:
                        info["title"] = str(fr.text[0]) if getattr(fr, "text", None) else None
                    elif k.startswith("TPE1") and not info["artist"]:
                        info["artist"] = str(fr.text[0]) if getattr(fr, "text", None) else None
                    elif k.startswith("TALB") and not info["album"]:
                        info["album"] = str(fr.text[0]) if getattr(fr, "text", None) else None
                    elif k.startswith("TPE2") and not info["album_artist"]:
                        info["album_artist"] = str(fr.text[0]) if getattr(fr, "text", None) else None
                    elif k.startswith("TRCK") and not info["track"]:
                        info["track"] = str(fr.text[0]) if getattr(fr, "text", None) else None
                    elif k.startswith("USLT") and not info["lyrics"]:
                        info["lyrics"] = str(fr.text) if getattr(fr, "text", None) else None
                    elif k.startswith("APIC"):
                        info["has_cover"] = True
                except Exception:
                    continue
    except Exception:
        pass

    info["has_lyrics"] = bool(info["lyrics"])
    return info


def read_cover(path: str) -> bytes:
    """读取文件现有嵌入封面，返回 bytes（无则空）。"""
    ext = os.path.splitext(path)[1].lstrip(".").lower()
    try:
        if ext == "mp3":
            a = ID3(path)
            for k in a.keys():
                if k.startswith("APIC"):
                    return bytes(a[k].data)
        elif ext == "flac":
            a = FLAC(path)
            if a.pictures:
                return bytes(a.pictures[0].data)
        elif ext in ("m4a", "mp4"):
            a = MP4(path)
            if a.get("covr"):
                return bytes(a["covr"][0])
        elif ext in ("ogg", "opus"):
            a = OggVorbis(path)
            if "metadata_block_picture" in a:
                import base64
                p = Picture(base64.b64decode(a["metadata_block_picture"][0]))
                return bytes(p.data)
        elif ext == "wav":
            tags = getattr(WAVE(path), "tags", None)
            if tags:
                for k in tags.keys():
                    if k.startswith("APIC"):
                        return bytes(tags[k].data)
    except Exception:
        return b""
    return b""


def identify(path: str, prefer_existing=True) -> dict:
    """识别单文件，返回 {parsed, best, candidates}"""
    parsed = parse_filename(path)
    artist, title, album = parsed["artist"], parsed["title"], None

    cands = build_candidates(artist, title, album)
    if not cands:
        return {"parsed": parsed, "best": None, "candidates": []}

    best = cands[0]
    return {"parsed": parsed, "best": best, "candidates": cands}


# ---------------------------------------------------------------- 封面
def fetch_cover(url_or_bytes, max_size=1000) -> bytes:
    """按 url 抓封面，PIL 压缩到 max_size 内，返回 JPEG bytes。"""
    data = url_or_bytes if isinstance(url_or_bytes, bytes) else None
    if data is None and url_or_bytes:
        try:
            r = requests.get(url_or_bytes, timeout=20, headers=UA)
            r.raise_for_status()
            data = r.content
        except Exception:
            return b""
    if not data:
        return b""
    if HAS_PIL:
        try:
            im = Image.open(io.BytesIO(data))
            im.thumbnail((max_size, max_size))
            if im.mode != "RGB":
                im = im.convert("RGB")
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=90)
            return buf.getvalue()
        except Exception:
            pass
    return data


def resolve_cover(best, candidates=None) -> bytes:
    """
    按优先级拿封面：best 的图 -> 其他候选的封面兜底 -> Cover Art Archive。
    保证即使 best 是 MusicBrainz 候选(无封面)，也能从 iTunes/Deezer 候选拿到封面。
    """
    candidates = candidates or []

    # 1) best 自己的封面
    if best and best.get("cover_url"):
        data = fetch_cover(best["cover_url"])
        if data:
            return data

    # 2) 其他候选的封面（按 score 排序，跳过无封面的）
    for c in candidates:
        if c is best:
            continue
        if c.get("cover_url"):
            data = fetch_cover(c["cover_url"])
            if data:
                return data

    # 3) Cover Art Archive（需要 MBID）
    for c in [best] + candidates:
        if c and c.get("mbid"):
            raw = _cover_art_archive(c["mbid"])
            if raw:
                return raw
    return b""


# ---------------------------------------------------------------- 歌词
LYRIC_LANG = "chi"  # USLT 语言字段 (3位 ISO 639-2)
NETEASE_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
              "Referer": "https://music.163.com/"}


def _fetch_lyrics_lrclib(artist=None, title=None) -> str:
    """渠道1: lrclib.net（免费无key，LRC 质量高，国际曲目全）。"""
    params = {}
    if artist:
        params["artist_name"] = clean_artist(artist)
    if title:
        params["track_name"] = title
    if not params:
        return ""
    try:
        url = "https://lrclib.net/api/get?" + urllib.parse.urlencode(params)
        r = requests.get(url, timeout=15, headers=UA)
        if r.status_code != 200:
            return ""
        d = r.json()
        return (d.get("syncedLyrics") or d.get("plainLyrics") or "")
    except Exception:
        return ""


def _fetch_lyrics_netease(artist=None, title=None) -> str:
    """渠道2: 网易云音乐（中文主流曲目全，弥补 lrclib 中文盲区）。"""
    if not title:
        return ""
    try:
        # 搜索：优先 artist+title，命中则取；否则纯 title
        def _search(q):
            r = requests.get("https://music.163.com/api/search/get/web",
                             params={"s": q, "type": 1, "limit": 8}, timeout=15, headers=NETEASE_UA)
            r.raise_for_status()
            return r.json().get("result", {}).get("songs", [])

        songs = []
        if artist:
            songs = _search(f"{clean_artist(artist)} {title}")
        if not songs:
            songs = _search(title)
        if not songs:
            return ""

        # 选匹配度最高的：标题相似 + 艺术家包含
        target = None
        best_score = -1
        for s in songs:
            nm = s.get("name") or ""
            artists = [a.get("name", "") for a in (s.get("artists") or [])]
            sc = sim(title, nm) * 5
            if artist:
                if any(clean_artist(artist) and (clean_artist(artist) in a or a in clean_artist(artist))
                       for a in artists):
                    sc += 3
            if sc > best_score:
                best_score = sc
                target = s

        if not target or best_score < 4.0:
            return ""

        sid = target.get("id")
        lr = requests.get("https://music.163.com/api/song/lyric",
                           params={"id": sid, "lv": 1, "kv": 1, "tv": -1},
                           timeout=15, headers=NETEASE_UA)
        lr.raise_for_status()
        lyric = (lr.json().get("lrc") or {}).get("lyric") or ""
        return lyric.strip()
    except Exception:
        return ""


def _fetch_lyrics_qqmusic(artist=None, title=None) -> str:
    """渠道3: QQ音乐（中文曲目全、遮字快，返回明文 LRC）。"""
    if not title:
        return ""
    try:
        def _search(q):
            r = requests.get("https://c.y.qq.com/soso/fcgi-bin/client_search_cp",
                             params={"w": q, "format": "json", "p": 1, "n": 6},
                             timeout=15, headers=QQ_HEADERS)
            r.raise_for_status()
            return r.json().get("data", {}).get("song", {}).get("list", [])

        songs = []
        if artist:
            songs = _search(f"{clean_artist(artist)} {title}")
        if not songs:
            songs = _search(title)
        if not songs:
            return ""

        target = None
        best_score = -1
        for s in songs:
            nm = s.get("songname") or ""
            singers = "、".join(x.get("name", "") for x in (s.get("singer") or []))
            sc = sim(title, nm) * 5
            if artist:
                ca = clean_artist(artist)
                for sg in (s.get("singer") or []):
                    a = sg.get("name", "")
                    if ca and (ca in a or a in ca):
                        sc += 3
                        break
            if sc > best_score:
                best_score = sc
                target = s

        if not target or best_score < 4.0:
            return ""

        songmid = target.get("songmid")
        r2 = requests.get("https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg",
                          params={"songmid": songmid, "format": "json", "nobase64": 1, "g_tk": 5381},
                          timeout=15, headers=QQ_HEADERS)
        r2.raise_for_status()
        d = r2.json()
        lyric = d.get("lyric") or ""
        return lyric.strip()
    except Exception:
        return ""


def _fetch_lyrics_kugou(artist=None, title=None) -> str:
    """渠道4: 酷狗音乐（中文曲目兜底）。"""
    if not title:
        return ""
    try:
        def _search(q):
            r = requests.get("http://mobilecdn.kugou.com/api/v3/search/song",
                             params={"format": "json", "keyword": q, "page": 1, "pagesize": 6},
                             timeout=15, headers=KG_HEADERS)
            r.raise_for_status()
            return r.json().get("data", {}).get("info", [])

        songs = []
        if artist:
            songs = _search(f"{clean_artist(artist)} {title}")
        if not songs:
            songs = _search(title)
        if not songs:
            return ""

        target = None
        best_score = -1
        for s in songs:
            nm = s.get("songname") or ""
            sn = s.get("singername") or ""
            sc = sim(title, nm) * 5
            if artist:
                ca = clean_artist(artist)
                if ca and (ca in sn or sn.replace("、", " ") in ca or ca.replace(" ", "") in sn.replace("、", "")):
                    sc += 3
            if sc > best_score:
                best_score = sc
                target = s

        if not target or best_score < 4.0:
            return ""

        h = target.get("hash")
        songname = target.get("songname") or title
        # 搜歌词 id + accesskey
        r2 = requests.get("http://lyrics.kugou.com/search",
                          params={"ver": 1, "man": "yes", "client": "pc", "keyword": songname, "hash": h},
                          timeout=15, headers=KG_HEADERS)
        r2.raise_for_status()
        cands = r2.json().get("candidates", [])
        if not cands:
            return ""
        cid = cands[0].get("id")
        accesskey = cands[0].get("accesskey")
        # 下载歌词
        r3 = requests.get("http://lyrics.kugou.com/download",
                          params={"ver": 1, "client": "pc", "id": cid, "accesskey": accesskey,
                                  "fmt": "lrc", "charset": "utf8"},
                          timeout=15, headers=KG_HEADERS)
        r3.raise_for_status()
        content = (r3.json() or {}).get("content", "")
        if not content:
            return ""
        if not content.lstrip().startswith("["):
            import base64 as _b64
            try:
                content = _b64.b64decode(content).decode("utf-8", errors="ignore")
            except Exception:
                return ""
        return content.strip()
    except Exception:
        return ""


# 歌词渠道（按顺序尝试，前一渠道失败自动切换下一个）
LYRIC_CHANNELS = [_fetch_lyrics_lrclib, _fetch_lyrics_netease, _fetch_lyrics_qqmusic, _fetch_lyrics_kugou]


def fetch_lyrics(artist=None, title=None, album=None) -> str:
    """多渠道获取歌词，首选 lrclib，失败换网易云。返回 LRC 或纯文本。"""
    for ch in LYRIC_CHANNELS:
        try:
            lyric = ch(artist, title)
            if lyric:
                return lyric
        except Exception:
            continue
    return ""


# ---------------------------------------------------------------- 写标签
def write_tags(path: str, meta: dict, cover: bytes = b"", lyrics: str = "") -> bool:
    """
    meta: {title, artist, album, album_artist, track}
    返回 True 表示成功（无覆盖则返回 True 表示不需要处理）。
    """
    if not os.path.exists(path):
        return False
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".mp3":
            audio = ID3(path)
        else:
            audio = MFile(path, easy=False)
        if audio is None:
            return False
    except Exception:
        # 新文件没有标签
        if ext == ".mp3":
            audio = ID3()
        else:
            audio = MFile(path, easy=False)
        if audio is None:
            return False

    if ext == ".mp3":
        if meta.get("title"):
            audio.add(TIT2(encoding=3, text=meta["title"]))
        if meta.get("artist"):
            audio.add(TPE1(encoding=3, text=meta["artist"]))
        if meta.get("album"):
            audio.add(TALB(encoding=3, text=meta["album"]))
        if meta.get("album_artist"):
            audio.add(TPE2(encoding=3, text=meta["album_artist"]))
        if meta.get("track"):
            audio.add(TRCK(encoding=3, text=str(meta["track"])))
        if cover:
            # 覆盖旧封面
            for k in list(audio.keys()):
                if k.startswith("APIC"):
                    del audio[k]
            audio.add(APIC(encoding=3, mime="image/jpeg", type=3,
                           desc="Cover", data=cover))
        if lyrics:
            for k in list(audio.keys()):
                if k.startswith("USLT"):
                    del audio[k]
            audio.add(USLT(encoding=3, lang=LYRIC_LANG, desc="", text=lyrics))
        # 强制 v2.3，兼容 Windows 资源管理器 / WMP / 老播放器
        try:
            audio.update_to_v24 = False
        except Exception:
            pass
        audio.save(path)

    elif ext == ".flac":
        audio = FLAC(path)
        if meta.get("title"):
            audio["title"] = meta["title"]
        if meta.get("artist"):
            audio["artist"] = meta["artist"]
        if meta.get("album"):
            audio["album"] = meta["album"]
        if meta.get("album_artist"):
            audio["albumartist"] = meta["album_artist"]
        if meta.get("track"):
            audio["tracknumber"] = str(meta["track"])
        if cover:
            audio.clear_pictures()
            pic = Picture()
            pic.type = 3
            pic.mime = "image/jpeg"
            pic.data = cover
            audio.add_picture(pic)
        if lyrics:
            audio["lyrics"] = lyrics
        audio.save()

    elif ext in (".m4a", ".mp4"):
        audio = MP4(path)
        if meta.get("title"):
            audio["\xa9nam"] = meta["title"]
        if meta.get("artist"):
            audio["\xa9ART"] = meta["artist"]
        if meta.get("album"):
            audio["\xa9alb"] = meta["album"]
        if meta.get("album_artist"):
            audio["aART"] = meta["album_artist"]
        if meta.get("track"):
            try:
                audio["trkn"] = [(int(meta["track"]), 0)]
            except Exception:
                pass
        if cover:
            audio["covr"] = [MP4Cover(cover, imageformat=MP4Cover.FORMAT_JPEG)]
        if lyrics:
            audio["\xa9lyr"] = lyrics
        audio.save()

    elif ext in (".ogg", ".opus"):
        audio = OggVorbis(path)
        if meta.get("title"):
            audio["title"] = meta["title"]
        if meta.get("artist"):
            audio["artist"] = meta["artist"]
        if meta.get("album"):
            audio["album"] = meta["album"]
        if meta.get("album_artist"):
            audio["albumartist"] = meta["album_artist"]
        if meta.get("track"):
            audio["tracknumber"] = str(meta["track"])
        if cover:
            pic = Picture()
            pic.type = 3
            pic.mime = "image/jpeg"
            pic.data = cover
            audio["metadata_block_picture"] = [pic.write().decode("ascii")]
        if lyrics:
            audio["lyrics"] = lyrics
        audio.save()

    elif ext == ".wav":
        # WAV 通过 ID3v2 标签内嵌封面/歌词（多数播放器认）
        audio = WAVE(path)
        tags = audio.tags
        if tags is None:
            # 文件尚无 ID3 标签，需要创建（add_tags 会绑定 filename）
            audio.add_tags()
            tags = audio.tags
        if tags is None:
            return False
        if meta.get("title"):
            tags.add(TIT2(encoding=3, text=meta["title"]))
        if meta.get("artist"):
            tags.add(TPE1(encoding=3, text=meta["artist"]))
        if meta.get("album"):
            tags.add(TALB(encoding=3, text=meta["album"]))
        if meta.get("album_artist"):
            tags.add(TPE2(encoding=3, text=meta["album_artist"]))
        if meta.get("track"):
            tags.add(TRCK(encoding=3, text=str(meta["track"])))
        if cover:
            for k in list(tags.keys()):
                if k.startswith("APIC"):
                    del tags[k]
            tags.add(APIC(encoding=3, mime="image/jpeg", type=3,
                          desc="Cover", data=cover))
        if lyrics:
            for k in list(tags.keys()):
                if k.startswith("USLT"):
                    del tags[k]
            tags.add(USLT(encoding=3, lang=LYRIC_LANG, desc="", text=lyrics))
        try:
            audio.update_to_v24 = False
        except Exception:
            pass
        audio.save(path)

    else:
        # WAV/APE/WMA 等不支持内嵌封面 → 旁挂 folder.jpg（多数播放器认这个）
        if cover:
            try:
                folder = os.path.dirname(path)
                with open(os.path.join(folder, "folder.jpg"), "wb") as f:
                    f.write(cover)
            except Exception:
                pass
        return True

    return True


# ---------------------------------------------------------------- 扫描
def scan_folder(folder: str):
    files = []
    for root, _, names in os.walk(folder):
        for n in sorted(names):
            if os.path.splitext(n)[1].lower() in AUDIO_EXTS:
                files.append(os.path.join(root, n))
    return files


def process_one(fp: str, want_cover: bool = True, want_lyrics: bool = True) -> dict:
    """
    单文件完整处理：识别 -> 封面 -> 歌词。返回结果 dict（供多线程/CLI 复用）。
    """
    res = identify(fp)
    best = res.get("best")
    cover = b""
    cover_fail = False
    lyrics = ""
    lyrics_fail = False

    if best and want_cover:
        cover = resolve_cover(best, res.get("candidates", []))
        if not cover:
            cover_fail = True
    if best and want_lyrics:
        lyrics = _fetch_lyrics_smart(res, best)
        if not lyrics:
            lyrics_fail = True

    return {
        "parsed": res["parsed"],
        "best": best,
        "candidates": res.get("candidates", []),
        "cover": cover,
        "cover_fail": cover_fail,
        "lyrics": lyrics,
        "lyrics_fail": lyrics_fail,
    }


def _fetch_lyrics_smart(res: dict, best: dict) -> str:
    """
    智能歌词查询：优先用文件名原始标题（清洗版本后缀后）查询，
    识别结果标题兑底。多组候选提高命中率。
    """
    parsed = res.get("parsed") or {}
    fname_title = parsed.get("title")
    fname_artist = parsed.get("artist")
    best_title = best.get("title")
    best_artist = best.get("artist")

    candidates = []
    if fname_title:
        t = strip_version_suffix(fname_title)
        if t:
            candidates.append((fname_artist, t))
    if fname_title:
        candidates.append((fname_artist, fname_title))
    if best_title:
        t = strip_version_suffix(best_title)
        if t:
            candidates.append((best_artist, t))
    if best_title:
        candidates.append((best_artist, best_title))

    seen = set()
    for artist, title in candidates:
        key = (clean_artist(artist or ""), title or "")
        if key in seen:
            continue
        seen.add(key)
        lyric = fetch_lyrics(artist, title)
        if lyric:
            return lyric
    return ""


def process_many(files, want_cover=True, want_lyrics=True, workers=4, progress=None):
    """
    多线程批量处理。workers 默认 4（各公开 API 无 key 限流较宽松，4-6 线程安全，
    不易触发封禁；太高易被临时限流/429）。progress 为可选回调 progress(done, total)。
    返回 {filepath: result}（保持输入顺序）。
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    results = {}
    n = len(files)
    if n == 0:
        return results
    # 每个线程内部加微小抖动，避免瞬间打满某个源
    import random as _random
    def _work(item):
        i, fp = item
        time.sleep(_random.uniform(0, 0.15))
        return i, fp, process_one(fp, want_cover, want_lyrics)

    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(_work, (i, fp)): i for i, fp in enumerate(files)}
        for fut in as_completed(futs):
            try:
                i, fp, result = fut.result()
            except Exception:
                # 单个文件处理出错不中断整体
                continue
            results[fp] = result
            done += 1
            if progress:
                try:
                    progress(done, n)
                except Exception:
                    # 进度回调出错（如 tkinter 线程问题）不影响结果收集
                    pass
    # 保持顺序
    ordered = {fp: results[fp] for fp in files if fp in results}
    return ordered


# ---------------------------------------------------------------- CLI 测试入口
if __name__ == "__main__":
    import argparse
    import json

    ap = argparse.ArgumentParser(description="MusicTagger CLI")
    ap.add_argument("path", nargs="+", help="文件或文件夹")
    ap.add_argument("--write", action="store_true", help="写回标签")
    ap.add_argument("--cover", action="store_true", help="下载封面")
    args = ap.parse_args()

    files = []
    for p in args.path:
        if os.path.isdir(p):
            files += scan_folder(p)
        elif os.path.isfile(p):
            files.append(p)

    for fp in files:
        res = identify(fp)
        best = res["best"]
        print(f"\n== {os.path.basename(fp)}")
        print(f"  解析: {res['parsed']}")
        if not best:
            print("  ✗ 未识别到")
            continue
        print(f"  ✓ [{best['source']}] 标题={best['title']!r} 艺术家={best['artist']!r} "
              f"专辑={best['album']!r} (score={best['score']})")
        if args.cover or args.write:
            cover = resolve_cover(best, res["candidates"])
            print(f"  封面: {'✓ ' + str(len(cover)) + 'B' if cover else '✗ 未找到'}")
        lyrics = ""
        if args.write:
            lyrics = _fetch_lyrics_smart(res, best)
            print(f"  歌词: {'✓ ' + str(len(lyrics)) + '字符' if lyrics else '✗ 未找到'}")
        if args.write:
            ok = write_tags(fp, {
                "title": best["title"], "artist": best["artist"],
                "album": best["album"], "album_artist": best.get("album_artist"),
                "track": res["parsed"]["track"],
            }, cover if args.cover else b"", lyrics)
            print(f"  写入: {'✓' if ok else '✗'}")
